import ccxt

# "api_key":"a7d9b18b-f180-4d1c-8a23-7f9181f0a21d","secret":"BDE5AC3D708763D67E243FB3BD808596","password":"reNyI598526436@"
exchange = ccxt.okex5({
    'apiKey': 'a7d9b18b-f180-4d1c-8a23-7f9181f0a21d',
    'secret': 'BDE5AC3D708763D67E243FB3BD808596',
    'password': 'reNyI598526436@',
    'timeout': 30000,
    'enableRateLimit': True
})

ticker = exchange.fetch_ticker(symbol="BTC/USDT")
print("ticker:", ticker)
# import urllib3
#
# print(urllib3.__version__)